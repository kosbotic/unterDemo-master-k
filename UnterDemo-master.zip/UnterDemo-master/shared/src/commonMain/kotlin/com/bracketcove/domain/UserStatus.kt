package com.bracketcove.domain

enum class UserStatus {
    INACTIVE,
    SEARCHING,
    IN_RIDE
}