package com.bracketcove.domain

enum class RideStatus {
    SEARCHING_FOR_DRIVER,
    PASSENGER_PICK_UP,
    EN_ROUTE,
    ARRIVED
}