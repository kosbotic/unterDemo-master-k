package com.bracketcove.domain

enum class UserType {
    PASSENGER,
    DRIVER
}