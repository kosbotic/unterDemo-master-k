## Project Overview

TBD...

## Libraries

### Android
* SimpleStack for Navigation
* Compose and XML for Views
* Firebase for Auth and User data persistence
* Stream Chat SDK for Driver-Passenger Chat
* Jetpack ViewModel
* Google Maps, Places, and GeoCoder

### iOS
* Swift UI

## Acknowledgements
Cyber Shark - Font choice
Josh (CMYUI) - BE consulting
