package com.bracketcove.android.dashboards.driver

import androidx.lifecycle.ViewModel

class DriverDashboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}