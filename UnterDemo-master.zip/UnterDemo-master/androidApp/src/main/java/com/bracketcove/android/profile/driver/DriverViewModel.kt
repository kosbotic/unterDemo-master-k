package com.bracketcove.android.profile.driver

import androidx.lifecycle.ViewModel

class DriverViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}