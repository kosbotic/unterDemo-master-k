package com.bracketcove.android.dashboards.passenger

import androidx.lifecycle.ViewModel

class PassengerDashboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}