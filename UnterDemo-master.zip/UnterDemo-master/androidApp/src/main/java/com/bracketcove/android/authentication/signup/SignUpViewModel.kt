package com.bracketcove.android.authentication.signup

import androidx.lifecycle.ViewModel

class SignUpViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}