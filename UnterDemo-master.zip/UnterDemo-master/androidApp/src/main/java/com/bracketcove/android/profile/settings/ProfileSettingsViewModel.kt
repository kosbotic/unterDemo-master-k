package com.bracketcove.android.profile.settings

import androidx.lifecycle.ViewModel

class ProfileSettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}